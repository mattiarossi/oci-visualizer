
require(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout', 'ojs/ojcheckboxset', 'ojs/ojbutton', 'ojs/ojtoolbar', 'ojs/ojmenu'],
function(oj, ko, $)
{

function ToolbarModel() {
    // if the contents of the array can change, then replace the [...] with ko.observableArray([...])
    this.drinkValues = [
        {id: 'coffee', label: 'Coffee'},
        {id: 'tea',    label: 'Tea'},
        {id: 'milk',   label: 'Milk'},
    ];
    
    // if the contents of the array can change, then replace the [...] with ko.observableArray([...])
    this.someButtons = [
        {id: 'Library',  icon: 'demo-icon-font demo-library-icon-24'},
        {id: 'Home', icon: 'demo-icon-font demo-home-icon-24'},
        {id: 'Grid',  icon: 'oj-fwk-icon-grid oj-fwk-icon'}
    ];
    
    this.toolbarClassNames = ko.observableArray([]);

    this.toolbarClasses = ko.computed(function() {
        return this.toolbarClassNames().join(" ");
    }, this);
}

$(function() {
    ko.applyBindings(new ToolbarModel(), document.getElementById('toolbar-container'));
});

});
