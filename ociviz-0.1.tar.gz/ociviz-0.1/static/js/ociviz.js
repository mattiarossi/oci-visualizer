/*
---------------------------------------------------------------------------
     ___  ____     _    ____ _     _____
    / _ \|  _ \   / \  / ___| |   | ____|
   | | | | |_) | / _ \| |   | |   |  _|
   | |_| |  _ < / ___ | |___| |___| |___
    \___/|_| \_/_/   \_\____|_____|_____|   OCI Visualization Tool

 
Author Michel Benoliel
Oracle 
---------------------------------------------------------------------------
*/ 

const background = new Image();

background.onload = () => {

	var qtipName = document.getElementById('qtipName');
	var qtipType = document.getElementById('qtipType');
	var qtipParent = document.getElementById('qtipParent');
	var qtipChildren = document.getElementById('qtipChildren');
	var qtipArea = document.getElementById('qtipAreaDetails');
	var acc = document.getElementsByClassName("accordion");
	var i;
	var data;
	var mylayout;
	var vcns = [];
	var lpgwsById = {};
	var vcnsById = {};
	var api;
	var alldata;
	var selectedCompName;
	var compartments;
	var dict = {};
	var compsCombo = document.getElementById('compsCombo');
	var vcnsCombo = document.getElementById('vcnsCombo');
	var detailsAccordion = document.getElementById('detailsAccordion');
	var ocids = {};
	var volumes = {};
	var cy;
	ocids["1"] = "hello";

	var protocols = ['HOPOPT', 'ICMP', 'IGMP', 'GGP', 'IPv4', 'ST', 'TCP', 'CBT', 'EGP', 'IGP', 'BBN-RCC-MON'];
	$("#propsAccordion").accordion();


	$("#routeDialog").dialog({
			autoOpen: false
	});
//	$("#propertiesDialog").dialog({
//		autoOpen: false
//	});
	$("#secListDialog").dialog({
		autoOpen: false
	});
	$("#vnicsDialog").dialog({
		autoOpen: false
	});
	$("#volumesDialog").dialog({
		autoOpen: false
	});
	$("#propertiesDialog").resizable();

	$(function() {
		$("#propertiesDialog").dialog({
		  autoOpen: false,
		  height: 400,
		  width: 400,
		  modal: true,
		  open: function(){
			$("#propsAccordion").accordion({ autoHeight: true });
			$( "#propsAccordion" ).accordion("refresh");	
		  }
		});
	  });
	var ajaxurl  = "http://" + $(location).attr('host');
	$.urlParam = function (name) {
		var results = new RegExp('[\?&]' + name + '=([^&#]*)')
			.exec(window.location.search);

		return (results !== null) ? results[1] || 0 : false;
	}

	var responseFilename = "network.json"
	var profile = $.urlParam('profile');
	if (profile == 'undefined' || profile == false)
		profile = 'DEFAULT';
	var compartment = $.urlParam('compartment');
	var proxy = $.urlParam('proxy');
	var mode = $.urlParam('mode');
	if (mode == 'undefined' || mode == false)
		mode = 'REST';

	var compInput = document.getElementById('compsCombo');
	$("#compsCombo").change(function () {
		compName = $(this).val();

		enableCompartment(compName, compartments, api);

	});

	populateCompartmentCombo(profile, compartment);

	function processCompartment(proifle, compartment) {

		var url1 = ajaxurl + "/visualize_compartment?profile=" + profile + "&compartment=" + compartment + "&proxy=" + proxy + "&mode=" + mode;
		var settings = {
			'cache': false,
			'dataType': "jsonp",
			"async": true,
			"crossDomain": true,
			"url": url1,
			"method": "GET",
			"headers": {
				"accept": "application/json",
				"Access-Control-Allow-Origin": "*"
			}
		}

		$("body").css("cursor", "progress");
		$.ajax(settings).then(function (response) {
			if (mode == "FILE"){
				alert ("Result successfully writter to file ./static/network_" + compartment + ".json");
				
			}
				
			$("body").css("cursor", "default");
			alldata = response.data;
			

			cy = cytoscape({
					container: document.getElementById("cy"),
					style: [{
							"selector": "[type = \"region\"]",
							css: {
								'font-size' : 14,
								'shape': 'rectangle',
								'background-color': 'hsl(0, 0%, 100%)',
								'label': "data(name)",
								'border-color': 'orange',
								'border-width': 3,
								'text-halign': "center",
								'text-valign': "top"

							}
						}, {
							"selector": "[type = \"oci_compartment\"]",
							css: {
								'font-size' : 10,
								'shape': 'rectangle',
								'background-color': 'hsl(0, 0%, 100%)',
								'label': "data(name)",
								'border-color': 'black',
								'border-width': 4,
								'text-halign': "left",
								'text-valign': "bottom"

							}
						}, {
							"selector": "[type = \"oci_vcn\"]",
							css: {
								'font-size' : 10,
								'shape': 'rectangle',
								'background-color': 'hsl(0, 0%, 100%)',
								'label': "data(name)",
								'border-color': 'orange',
								'border-style': 'dashed',
								'border-width': 4,
								'text-halign': "left",
								'text-valign': "bottom"

							}
						}, {
							"selector": "[type = \"oci_ad\"]",
							css: {
								'font-size' : 10,

								'shape': 'rectangle',
								'background-color': 'hsl(0, 0%, 100%)',
								'label': "data(name)",
								'border-color': 'grey',
								'border-width': 5

							}
						}, {
							selector: 'node[type="subnet"]',
							css: {
								'font-size' : 10,
								'min-width': '100px',
								'min-height': '100px',
								"label": "data(name) ",
								'shape': 'rectangle',
								'background-color': 'hsl(0, 100%, 106%)',
								'border-color': "data(color)",
								'border-width': 3,
								'border-style': 'dashed',
								"width": 'label'

							}
						}, {
							"selector": "[type = \"oci_vm\"]",
							"css": {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/VM.png",
								"background-fit": "contain",
								"background-clip": "none",
								"width": 'label'
							}
						},  {
							"selector": "[type = \"oci_bm\"]",
							"css": {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/BareMetal.png",
								"background-fit": "contain",
								"background-clip": "none",
								"width": 'label'
							}
						},{
							"selector": "[type = \"oci_dbcs\"]",
							"css": {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/Database.png",
								"background-fit": "contain",
								"background-clip": "none",
								"width": 'label'
							}
						}, {
							"selector": "[type = \"oci_lb\"]",
							"css": {
								"label": "data(name)",
								'font-size' : 10,
								"background-opacity": 0,
								"background-image": "./icons/oci/LoadBalancer.png",
								"background-fit": "contain",
								"background-clip": "none",
								"width": 'label'

							}
						}, {
							"selector": "[type = \"ip\"]",
							"css": {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/CustomerDataCenter.png",
								"background-fit": "contain",
								"background-clip": "none"
							}
						}, {
							"selector": "[type = \"oci_igw\"]",
							"css": {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/InternetGateway.png",
								"background-fit": "contain",
								"background-clip": "none"
							}
						}, {
							"selector": "[type = \"oci_lpgw\"]",
							"css": {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/LocalPeering2.png",
								"background-fit": "contain",
								"background-clip": "none"
							}
						}, {
							selector: 'node[type="oci_drg"]',
							css: {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/DRG.png",
								"background-fit": "contain",
								"background-clip": "none"
							}
						}, {
							selector: 'node[type="oci_cpe"]',
							css: {
								'font-size' : 10,
								"label": "data(name)",
								"background-opacity": 0,
								"background-image": "./icons/oci/CustomerPremiseEquipment.png",
								"background-fit": "contain",
								"background-clip": "none"
							}
						}, {
							selector: 'edge[type="edge"]',
							css: {
								'font-size' : 10,
								"curve-style": "bezier",
								"target-arrow-shape": "triangle",
								"control-point-step-size": 100,
								"label": "data(label)",
								"line-color": "black"
							}
						}, {
							selector: 'edge[type="edge-sl"]',
							css: {
								'font-size' : 10,
								"curve-style": "bezier",
								"target-arrow-shape": "triangle",
								"control-point-step-size": 100,
								"label": "data(label)",
								"line-color": "green"
							}
						}, {
							selector: 'edge[type="edge-rl"]',
							css: {
								'font-size' : 10,
								"curve-style": "bezier",
								"target-arrow-shape": "triangle",
								"control-point-step-size": 100,
								"label": "data(label)",
								"line-color": "blue"
							}
						}, {
							selector: 'edge[type="edge-lb"]',
							css: {
								'font-size' : 10,
								"curve-style": "bezier",
								"target-arrow-shape": "triangle",
								"control-point-step-size": 100,
								"label": "data(label)",
								"line-color": "orange"
							}
						}, {
							selector: 'edge[type="edge-lpgw"]',
							css: {
								'font-size' : 10,
								"curve-style": "bezier",
								"target-arrow-shape": "triangle",
								"control-point-step-size": 100,
								"label": "data(label)",
								"line-color": "red"
							}
						}, {
							selector: 'edge[type="edge-drg"]',
							css: {
								'font-size' : 10,
								"curve-style": "bezier",
								"target-arrow-shape": "triangle",
								"control-point-step-size": 100,
								"label": "data(label)",
								"line-color": "red"
							}
						}
					],

					elements: {}

				});
			
			// Set Context menu
			cy.contextMenus({
				menuItems: [{
						id: 'Properties',
						content: 'Show Properties',
						tooltipText: 'Show Properties',
						selector: 'node, edge',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							routeTable = ocids[target._private.data.qtip.route_table_id];

							showPropertiesDialog(target);

						}
					}, {
						id: 'showRouteTable',
						content: 'Route Table',
						tooltipText: 'Show Route table',
						selector: 'node[type ="subnet"]',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							routeTable = ocids[target._private.data.qtip.route_table_id];

							showRouteTable(routeTable, target._private.data.qtip.display_name);

						}
					}, {
						id: 'showSecRules',
						content: 'Security Lista',
						tooltipText: 'Show Security List',
						selector: 'node[type ="subnet"]',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							var securityLists = target._private.data.qtip.security_list_ids;
							showSecurityLists(securityLists, target._private.data.qtip.display_name);

						}
					}, {
						id: 'showVnics',
						content: 'Attached VNICs',
						tooltipText: 'Show Attached VNICs',
						selector: 'node[type ="oci_vm"]',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							var securityLists = target._private.data.qtip.security_list_ids;
							showAttachedVnics(target._private.data);

						}
					},{
						id: 'showVnicsBM',
						content: 'Attached VNICs',
						tooltipText: 'Show Attached VNICs',
						selector: 'node[type ="oci_bm"]',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							var securityLists = target._private.data.qtip.security_list_ids;
							showAttachedVnics(target._private.data);

						}
					},  {
						id: 'showBlockVolumes',
						content: 'Attached Block Volumes',
						tooltipText: 'Show Attached Block Volumes',
						selector: 'node[type ="oci_vm"]',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							var securityLists = target._private.data.qtip.security_list_ids;
							showAttachedBlockedVolumes(target._private.data);

						}
					},{
						id: 'showBlockVolumesBm',
						content: 'Attached Block Volumes',
						tooltipText: 'Show Attached Block Volumes',
						selector: 'node[type ="oci_bm"]',
						onClickFunction: function (event) {
							var target = event.target || event.cyTarget;
							var securityLists = target._private.data.qtip.security_list_ids;
							showAttachedBlockedVolumes(target._private.data);

						}
					},
				],
				menuItemClasses: ['custom-menu-item'],
				contextMenuClasses: ['custom-context-menu']
			});
			
			// Node Clicked
			cy.on('click', 'node', function (event) {
				showPropertiesDialog(this);

			});

			// edge Clicked
			cy.on('click', 'edge', function (event) {
				showPropertiesDialog(this);
			
//				qtipNameLabel.innerHTML = "		<b>Name:</b>" + this.data("name") + "		<b>Type: </b>" + this.data("type") + "		<b>Parent: </b>" + this.data("parentName") + "		<b> Children: </b>" + this.children().length;

//				qtipArea.value = 'Details:\n' + JSON.stringify(this.data("qtip"), null, 4);
//				$("#propertiesDialog").dialog("open");

			});

			// Initialize data
			$.each(alldata, function (i, obj) {
				var x = dict[obj.data.id];
				if (x == undefined) {
					dict[obj.data.id] = 1;
					if (obj.group == "nodes") {
						//						if (obj.data.type == "oci_compartment")
						//							compartments.push(obj.data);

						if (obj.data.type == "oci_vcn") {
							vcns.push(obj.data);
							vcnsById[obj.data.id] = obj.data;
						}
						if (obj.data.type == "oci_lpgw") {
							lpgwsById[obj.data.id] = obj.data;
						}

					}
				}
				if (obj.group == "ocids") {
					ocids[obj.data.id] = obj.data.node_data;
				} else 	if (obj.group == "volumes") {
					volumes[obj.data.id] = obj.data.node_data;
				}


			});
			
			// Select the requested compartment
			var comp;
			for (var i = 0; i < compartments.length; i++) {
				var item = compartments[i];
				var compEle = cy.getElementById(item.id);
				if (item.name == compartment) {
					compEle.show();
					populateVcnsCombo(item);
					comp = item;
				} else
					cy.remove(compEle);
			}

			// Handle view edges events
			$("#showRouteEdges").change(function () {
				enableElements(this.checked, "edge-rl");
			});
			$("#showSecRulesEdges").change(function () {
				enableElements(this.checked, "edge-sl");
			});
			$("#showLBEdges").change(function () {
				enableElements(this.checked, "edge-lb");
			});
			$("#showInstances").change(function () {
				enableElements(this.checked, "oci_vm");
				enableElements(this.checked, "oci_bm");
			});

			//	Handle VCN combo change
			$("#vcnsCombo").change(function () {
				var vcn_id;
				vcnName = $(this).val();
				enableVcn(vcnName, vcns);

			});
			
			
			//	Handle Compartment combo change
			$("#secListsCombo").change(function () {
				slid = $(this).val();
				populateSecurityList(slid);

			});

			mylayout = cy.layout({
					name: 'cose-bilkent',
					animate: false
				});
			mylayout.run();

			cleanupNodes();
			cy.zoom(2);
			cy.resize();

			api = cy.expandCollapse({
					layoutBy: {
						name: "cose-bilkent",
						animate: true,
						randomize: false,
						fit: true,
						padding: 30
					},
					fisheye: true,
					animate: true,
					undoable: false
				});

			const bottomLayer = cy.cyCanvas({
					zIndex: -1,
				});

		});

	}
	function cleanupNodes() {
		// trigger click event on accordion
		for (var j = 0; j < cy.nodes().length; j++) {
			if (cy.nodes()[j].data("type") == undefined)
				rn = cy.nodes()[j];
			cy.remove(rn);
		}
	}

	function enableCompartment(compName, compartments, api) {
		selectedCompName = compName;

		processCompartment(profile, compName);

	}

	
	// Enable the selected VCN
	function enableVcn(vcn, vcns) {
		dict = {}
		cy.elements().remove();

		var vcnname = vcnsCombo.value;
		for (var item of vcns) {

			if (item.name == vcnname) {
				vcn_id = item.id
					break;
			}
		}

		for (var item of compartments) {

			if (item.name == selectedCompName) {
				comp_id = item.id
					break;
			}
		}
		//$.each(data, function (i, obj) {
		for (var obj of alldata) {
			var x = dict[obj.data.id];
			if (x == undefined) {
				dict[obj.data.id] = 1;
				if ((obj.data.type == "region" || ((obj.data.type == "oci_compartment" || obj.data.type == "oci_drg" || obj.data.type == "oci_cpe") && obj.data.compartment_id == comp_id)) || (obj.group == "nodes" && obj.data.compartment_id == comp_id && (obj.data.vcn_id == vcn_id || vcnname == "*"))) {
					var myName = obj.data.name;
					var subnetColor = "red";
					if (obj.data.type == "oci_lb") {
						console.log("LoadBalancer:", obj)
					}
					if (obj.data.type == "subnet") {
						//myName = obj.data.name + " , " + obj.data.node_data.cidr_block;
						myName = obj.data.node_data.cidr_block;
						if (obj.data.node_data.prohibit_public_ip_on_vnic == false)
							subnetColor = "green";
						if (obj.data.node_data.route_table_id != undefined) {
							console.log("Found routetable:", obj.data.node_data.route_table_id);
							var routeTable = ocids[obj.data.node_data.route_table_id];
							console.log("Found routetable:", routeTable)
						}

					}
					if (obj.data.type == "oci_vcn")
						myName = obj.data.name + " , " + obj.data.node_data.cidr_block;
					//console.log("adding: " + obj.data.type + " : " + myName);
					cy.add({
						group: "nodes",
						data: {
							color: subnetColor,
							id: obj.data.id,
							qtip: obj.data.node_data,
							name: myName,
							display_name: obj.data.name,
							type: obj.data.type,
							parent: obj.data.parent,
							qtip: obj.data.node_data,
							parentName: obj.data.parentName
						}
					})
				} else if (obj.group == "edges" && obj.data.compartment_id == comp_id && (obj.data.vcn_id == vcn_id || vcnname == "*" || obj.data.type == "edge-drg")) {
					// edge is to a non exisitng local peering, so we create it
					if (obj.data.type == "edge-lpgw") {
						var edgeid = obj.data.id;
						var prefix = "peeredvcn.";
						var suffix = ":sourcelpgw";
						var peeredvcnId = edgeid.substring(edgeid.lastIndexOf(prefix) + prefix.length, edgeid.lastIndexOf(suffix));
						var peeredvcn = vcnsById[peeredvcnId];
						var peeredlpgw = lpgwsById[obj.data.target];
						var myvcnname = peeredvcn.node_data.display_name + ":" + peeredvcn.node_data.cidr_block
							// add the peered vcn
							cy.add({
								group: "nodes",
								data: {
									color: subnetColor,
									id: peeredvcn.id,
									qtip: peeredvcn.node_data,
									name: myvcnname,
									type: "oci_vcn",
									parent: peeredvcn.parent,
									qtip: peeredvcn.node_data,
									parentName: peeredvcn.parentName
								}
							});
						// add the peered local peering gateway
						cy.add({
							group: "nodes",
							data: {
								color: subnetColor,
								id: peeredlpgw.id,
								qtip: peeredlpgw.node_data,
								name: peeredlpgw.node_data.display_name,
								type: "oci_lpgw",
								parent: peeredvcn.id,
								qtip: peeredlpgw.node_data,
								parentName: peeredlpgw.parentName
							}
						});
					}

					var sourceNodex = cy.getElementById(obj.data.source);
					var targetNodex = cy.getElementById(obj.data.target);
					if (sourceNodex.length == 0) {
						console.log("source node:", obj.data.source, " does not exist");
						var sourceObj = getObjectById(alldata, obj.data.source);
						cy.add({
							group: "nodes",
							data: {
								color: subnetColor,
								id: sourceObj.data.id,
								qtip: sourceObj.data.node_data,
								name: sourceObj.data.name,
								type: sourceObj.data.type,
								qtip: sourceObj.data.node_data
							}
						});
					}
					if (targetNodex.length == 0)
						alert("target is undefined");

					cy.add({
						group: "edges",
						data: {
							id: obj.data.id,
							source: obj.data.source,
							target: obj.data.target,
							name: obj.data.name,
							type: obj.data.type,
							qtip: obj.data.node_data,
							label: obj.data.label
						}
					})
				}
			}
		}

		cy.resize();
		cy.zoom(1);

		mylayout = cy.layout({

				name: 'cose-bilkent',
				animate: 'end',
				nodeSep: 100, // >>>>>>YOUR TARGET PROPERTY<<<<<<<
				animationEasing: 'ease-out',
				animationDuration: 1000
			});

		mylayout.run();
		cy.fit(50);

	}

	// Populate the compartment compbo by issuing a REST request to the flask server
	function populateCompartmentCombo(profile, requiredCompartment) {
		console.log("profile:", profile);
		compartments = [];
		if (mode == "OFFLINE"){
			$.getJSON( "network.json", function( data ) {
				$.each(data, function (i, obj) {
					if (obj.data.type == "oci_compartment")
						compartments.push(obj.data.node_data);
				});
				requiredCompartment = compartments[0].	name;
				populateCompsCombo(requiredCompartment);

			});
		} else {
			$("body").css("cursor", "progress");

			var url1 = ajaxurl + "/list_compartments/" + profile + "?proxy=" + proxy +"&mode=" + mode;
				console.log("compurl", url1);
			var settings1 = {
				'cache': false,
				'dataType': "jsonp",
				"async": true,
				"crossDomain": true,
				"url": url1,
				"method": "GET",
				"headers": {
					"accept": "application/json",
					"Access-Control-Allow-Origin": "*"
				}
			}
			$.ajax(settings1).then(function (response) {
				compartments = response.data;
				populateCompsCombo(requiredCompartment);
			});
		}
	}

	function populateCompsCombo(requiredCompartment){
				document.getElementById('compsCombo').innerHTML = '';
				for (var i = 0; i < compartments.length; i++) {
					comp = compartments[i];
					// Create a new <option> element.
					var option1 = document.createElement('option');
					option1.text = comp.name;
					option1.value = comp.name;
					compsCombo.options.add(option1);

				}
				// select first compartment
				if (compartments.length > 0 && requiredCompartment != undefined) {
					compInput.value = requiredCompartment;
					enableCompartment(requiredCompartment, compartments, api);

				}
				$("body").css("cursor", "default");		
	}
	// Populate VCN combo
	function populateVcnsCombo(comp) {
		// clear the vcn datalist options
		document.getElementById('vcnsCombo').innerHTML = '';
		var vcnIsEmpty = true;
		var firstVcn;
		var option = document.createElement('option');
		option.value = "*";
		option.text = "All";
		vcnsCombo.options.add(option);

		vcns.forEach(function (item) {
			// Create a new <option> element.
			if (item.parent == comp.id) {
				var option = document.createElement('option');
				option.value = item.name;
				option.text = item.name;
				vcnsCombo.options.add(option);
				vcnIsEmpty = false;
				firstVcn = item;
			}
		});
		// select first VCN
		if (!vcnIsEmpty) {
			var vcnInput = document.getElementById('vcnsCombo');

			vcnInput.value = firstVcn.name;
			enableVcn(firstVcn, vcns);
		}

	}

	function enableElements(checked, type) {
		for (var i = 0; i < cy.elements().length; i++) {
			var ele = cy.elements()[i];
			if (ele.data("type") == type) {
				if (checked)
					ele.show();
				else
					ele.hide();
			}
		}
	}

	function getObjectById(objCollection, id) {
		for (var obj of objCollection) {
			if (obj.data.id == id)
				return obj;
		}
		return undefined;

	}

	function showPropertiesDialog(node) {
		$(function () {
			$(".accordion").accordion({
				collapsible: true,
				active: true,
				autoHeight:false
			});
		});
	qtipNameLabel.innerHTML = "		<b>Name:</b>" + node.data("display_name") + "		<b>Type: </b>" + node.data("type") + "		<b>Parent: </b>" + node.data("parentName") + "		<b> Children: </b>" + node.children().length;
		
 		var dataObj = node.data("qtip");
		
		var propsAccordion = document.getElementById("propsAccordion");
		$("#propsAccordion").empty();
		var mh3  = document.createElement('h3');
		var mdiv = document.createElement('div');
		mh3.innerHTML = node.data("name");
		propsAccordion.appendChild(mh3);
		propsAccordion.appendChild(mdiv);
		var table1 = document.createElement("table");
		table1.style.rows = 5;
		table1.style.cols = 20;
		for (var field in node.data("qtip")){
			var fieldVal = dataObj[field];
			if (!Array.isArray(fieldVal)){
				var tr = document.createElement("tr");
				var tdLabel = document.createElement("td");
				tdLabel.appendChild(document.createTextNode(field));				
				var tdVal = document.createElement("td");
				tdVal.appendChild(document.createTextNode(fieldVal));				
				tr.appendChild(tdLabel);
				tr.appendChild(tdVal);
				table1.appendChild(tr);
				child = fieldVal[i];
			
			}
		}
		
		mdiv.appendChild(table1);
		
		for (var field in node.data("qtip")){
		
			console.log(field + '=' + typeof(field) + " data:" + dataObj[field]);
			var fieldVal = dataObj[field];
			if (Array.isArray(fieldVal)){
				console.log (field + " isArray"  );
				var h3  = document.createElement('h3');
				var div = document.createElement('div');
				h3.innerHTML = field + "(" + fieldVal.length + ")";
				for (var i=0; i<fieldVal.length;i++) {
					child = fieldVal[i];
					for (var cField in child){
						label = document.createElement("label");
					label.innerHTML = cField + ": " + child[cField];
						div.appendChild(label);
						
					}
				}
				propsAccordion.appendChild(h3);
				propsAccordion.appendChild(div);
				
			} else{
			}
			
		} 
		

//		qtipArea.value = 'Details:\n' + JSON.stringify(node.data("qtip"), null, 4);

		
		
		

		$("#propertiesDialog").dialog("open");

	}
	function showRouteTable(routeTable, subnetName) {
		var title = $("#routeDialog").dialog("option", "title");
		$("#routeDialog").dialog("option", "title", "Route Table - " + subnetName);
		var tableBody = document.getElementById("routeTableTbl");
		// remove th rows except for the header
		for (var i = 1; i < tableBody.rows.length; i++)
			tableBody.deleteRow(i);
		for (var r = 0; r < routeTable.route_rules.length; r++) {
			rt = routeTable.route_rules[r];
			var tr = document.createElement('TR');
			var td1 = document.createElement('TD');
			td1.appendChild(document.createTextNode(rt.cidr_block));
			rtTarget = ocids[rt.network_entity_id];
			var targetType;
			if (rt.network_entity_id.startsWith("ocid1.internetgateway"))
				targetType = "Internet Gateway";
			else if (rt.network_entity_id.startsWith("ocid1.privateip"))
				targetType = "Private IP";
			else if (rt.network_entity_id.startsWith("ocid1.localpeeringgateway"))
				targetType = "Local Peering Gateway";
			var td2 = document.createElement('TD');
			td2.appendChild(document.createTextNode(targetType));
			var td3 = document.createElement('TD');
			td3.appendChild(document.createTextNode(rtTarget.name));
			tr.appendChild(td1);
			tr.appendChild(td2);
			tr.appendChild(td3);
			tableBody.appendChild(tr);
		}
		$("#routeDialog").dialog("open");

	}

	function showSecurityLists(securityLists, subnetName) {
		var title = $("#secListDialog").dialog("option", "title");
		$("#secListDialog").dialog("option", "title", "Security Lists - " + subnetName);

		var tableBody = document.getElementById("secListTableTbl");
		// remove th rows except for the header
		for (var i = 1; i < tableBody.rows.length; i++)
			tableBody.deleteRow(i);
		for (var slid of securityLists) {

			sl = ocids[slid];
			var option1 = document.createElement('option');
			option1.text = sl.display_name;
			option1.value = slid;
			secListsCombo.options.add(option1);
		}
		secListsCombo.value = securityLists[0];
		populateSecurityList(securityLists[0]);

		$("#secListDialog").dialog("open");

	}
	
	function showAttachedVnics(vmdata){
	
		var title = $("#vnicsDialog").dialog("option", "title");
		$("#vnicsDialog").dialog("option", "title", "Attached VNICs - " + vmdata.qtip.display_name);
		var tableBody = document.getElementById("vnicsTableTbl");
		// remove th rows except for the header
		for (var i = 1; i < tableBody.rows.length; i++)
			tableBody.deleteRow(i);
		for (var vnic of  vmdata.qtip.vnics) {
			var tr = document.createElement('TR');
			var td1 = document.createElement('TD');
			td1.appendChild(document.createTextNode(vnic.display_name));
			var td2 = document.createElement('TD');
			td2.appendChild(document.createTextNode(vnic.private_ip));
			var td3 = document.createElement('TD');
			td3.appendChild(document.createTextNode(vnic.public_ip));
			var td4 = document.createElement('TD');
			td4.appendChild(document.createTextNode(vnic.is_primary));
			var td5 = document.createElement('TD');
			td5.appendChild(document.createTextNode(vnic.mac_address));
			tr.appendChild(td1);
			tr.appendChild(td2);
			tr.appendChild(td3);
			tr.appendChild(td4);
			tr.appendChild(td5);
			tableBody.appendChild(tr);
		}
		$("#vnicsDialog").dialog("open");		

	}
	
	function showAttachedBlockedVolumes(vmdata){
		var title = $("#volumesDialog").dialog("option", "title");
		$("#volumesDialog").dialog("option", "title", "Attached Block Volumes - " + vmdata.qtip.display_name);
		var tableBody = document.getElementById("volumesTableTbl");
		// remove th rows except for the header
		for (var i = 1; i < tableBody.rows.length; i++)
			tableBody.deleteRow(i);
		for (var atVol of  vmdata.qtip.volumes) {
			var vol = volumes[atVol.volume_id];
			var tr = document.createElement('TR');
			var td1 = document.createElement('TD');
			td1.appendChild(document.createTextNode(vol.display_name));
			var td2 = document.createElement('TD');
			td2.appendChild(document.createTextNode(atVol.attachment_type));
			var td3 = document.createElement('TD');
			var isreadonly = "False";
			if (atVol.is_read_only != undefined)
				isreadonly = atVol.is_read_only;

			td3.appendChild(document.createTextNode(isreadonly));
			var td4 = document.createElement('TD');
			td4.appendChild(document.createTextNode(atVol.lifecycle_state));
			var td5 = document.createElement('TD');
			td5.appendChild(document.createTextNode(vol.size_in_gbs));
			tr.appendChild(td1);
			tr.appendChild(td2);
			tr.appendChild(td3);
			tr.appendChild(td4);
			tr.appendChild(td5);
			tableBody.appendChild(tr);
		}
		$("#volumesDialog").dialog("open");		
	}

	function populateSecurityList(slid) {
		var tableBody = document.getElementById("secListTableTbl");
		// remove th rows except for the header
		for (var i = 1; i < tableBody.rows.length; i++)
			tableBody.deleteRow(i);
		var sl = ocids[slid];
		for (var i = 1; i < sl.ingress_security_rules.length; i++) {
			var rl = sl.ingress_security_rules[i];
			var tr = document.createElement('TR');
			var td1 = document.createElement('TD');
			var td2 = document.createElement('TD');
			var td3 = document.createElement('TD');
			var td4 = document.createElement('TD');
			td1.appendChild(document.createTextNode(rl.source));
			td2.appendChild(document.createTextNode(protocols[rl.protocol]));
			if (rl.tcp_options != null) {
				if (rl.tcp_options.source_port_range != null)
					td3.appendChild(document.createTextNode(rl.tcp_options.source_port_range.min + ":" + rl.tcp_options.source_port_range.max));
				if (rl.tcp_options.destination_port_range != null)
					td4.appendChild(document.createTextNode(rl.tcp_options.destination_port_range.min + ":" + rl.tcp_options.destination_port_range.max));
			} else if (rl.icmp_options != null) {

				td3.appendChild(document.createTextNode(rl.icmp_options.type + ", " + rl.icmp_options.code));
			}
			tr.appendChild(td1);
			tr.appendChild(td2);
			tr.appendChild(td3);
			tr.appendChild(td4);
			tableBody.appendChild(tr);

		}
	}

};
// Preload images
background.src = "https://files.classcraft.com/classcraft-assets/images/event_scroll_middle.jpg";