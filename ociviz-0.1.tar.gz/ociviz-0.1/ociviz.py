"""
---------------------------------------------------------------------------
     ___  ____     _    ____ _     _____
    / _ \|  _ \   / \  / ___| |   | ____|
   | | | | |_) | / _ \| |   | |   |  _|
   | |_| |  _ < / ___ | |___| |___| |___
    \___/|_| \_/_/   \_\____|_____|_____|   OCI Visualization Tool

 
Author Michel Benoliel
Oracle 
---------------------------------------------------------------------------

"""

import datetime
import sys
import os
import uuid

import json
import simplejson
import oci
from oci.exceptions import ProfileNotFound
from oci.config import from_file
from oci.core import ComputeClient
from oci.core import BlockstorageClient
from oci.core.models.instance import Instance
from oci.database.database_client import DatabaseClient
from oci.load_balancer.load_balancer_client import LoadBalancerClient
from oci.load_balancer.models import CreateBackendDetails
from netaddr import IPNetwork, IPAddress
import ConfigParser
import argparse
import traceback
 
def main():
	generateGraphFile(sys.argv[1:])
	
def generateGraphFile(arguments):	
	
	global nodes, edges, subnets, vcns, dbs, ads, drgs, lbs, cidr, public_ips, verbose, ocids, external_cidrs, compArg, vcnArg, compute,database,network, identity, loadbalancer,blockstorage, lbs, rootCompartmentId, nodeNamesById, subnetsById, localPeeringGateways, privateIpsById, attached_volumes, volumes

	nodes = []	
	edges = []

	vcns = []
	subnets=[]
	privateIpsById = {}
	dbs = []
	ads = []
	drgs =[]
	lbs=[]
	cidr = IPNetwork('10.0.0.0/24')
	public_ips = []	
	attached_volumes = []
	volumes = []
	localPeeringGateways = []
	verbose = False
	ocids = {}
	external_cidrs = {}	
	nodeNamesById = {}
	subnetsById = {}

	log ("Arguments:",arguments)
	

	parser = argparse.ArgumentParser()
 	parser.add_argument("-p", "--profile", help="CLI profile to use",
                         type=str)
	parser.add_argument("-c","--compartment",help="compartment name or * for all compartments",
                         type=str)
	parser.add_argument("-v","--vcn",help="VCN name or * for all VCNs in compartment",
                         type=str)
 	parser.add_argument("-m", "--mode", help="REST or FILE or OFFLINE",
                         type=str)
	parser.add_argument("--proxy",help="proxy setting",
		type=str)
	parser.add_argument("--callback",help="jsonp callback",
		type=str)
	parser.add_argument("--_",help="jsonp callback",
		type=str)
	parser.add_argument("--verbose",help="verbose",
		action="store_true")
	try:
		args = parser.parse_args(arguments)
	except Exception as ex:
		print ex
	
	
	if args.verbose:
		verbose = True
	else:
		verbose = False

	profileArg = args.profile
	if args.profile == None:
		profileArg = "DEFAULT"
	compArg = args.compartment
	vcnArg = args.vcn
	
	print( "Running extractor with parameters: \n Profile:", profileArg, '\n compartment:', compArg, "\n VCN:", vcnArg, "\n proxy:", args.proxy, "\n mode:", args.mode)		

	
	# if test mode we return a fixed response from the nextwork.json file
	if args.mode == "OFFLINE":
		print "****** OFFLINE MODE ******"
		file = open(os.path.join("static","network.json"),'r')
		response = file.read()
		response = prepareresponse(response, args)
		return response
		
	
# read the config file
	try:
		config = from_file(profile_name=profileArg)
	except ProfileNotFound:
		errorMsg =  "Error: Profile " + profileArg + " not found in config file"
		print errorMsg
		response = "{'error':'" + errorMsg +  "'}"
		return prepareResponse(response, args)


	# get compartment id from name
	rootCompartmentId = config["tenancy"].strip()
	log("rootCompartmentId: " , rootCompartmentId)

	# get SDK clients
	compute  =  ComputeClient(config)
	database = DatabaseClient(config)
	network = oci.core.virtual_network_client.VirtualNetworkClient(config)
	identity = oci.identity.identity_client.IdentityClient(config)
	loadbalancer = LoadBalancerClient(config)
	blockstorage = BlockstorageClient(config)
	
	
	# add proxy to clients if proxy parameter is specified
	if args.proxy != "false":
		log  ("Info: using proxy " + args.proxy)
		compute.base_client.session.proxies = { 'https': args.proxy }
		network.base_client.session.proxies = { 'https': args.proxy }
		loadbalancer.base_client.session.proxies = { 'https': args.proxy }
		identity.base_client.session.proxies = { 'https': args.proxy }
		database.base_client.session.proxies = { 'https': args.proxy }
		blockstorage.base_client.session.proxies = { 'https': args.proxy }


	# create the region node
	regionId = config["tenancy"] + ":region/" + config["region"]
	region = {"id": regionId, "RegionName": config["region"]}
	nodes.append(createNode("","",region,"region",regionId,config["region"],""))	

	compId = ""

	# get root compartment
	rc = identity.get_compartment(rootCompartmentId).data
	# get listof compartments
	compartments = identity.list_compartments(rootCompartmentId).data
	# add root compartment to list
	compartments.append(rc)

	# check that given comprtment exists
	compId = ""
	compName = ""
	for comp in compartments:
		if (compArg == None or comp.name == compArg):
			compId = comp.id
			compName = comp.name
			createCompartment(regionId, comp)

	# create local  peering gateways nodes
	createLocalPeering(localPeeringGateways)
		
	
	# add the edges to the file
	for edge in edges:
		nodes.append(edge)
		
	# create  ocids nodes. We use ocids later in the visualization 
	for ocid in ocids.keys():
		node = {"group": "ocids", "data":{"id": ocid, "node_data":  ocids[ocid]}}
		nodes.append(node)

	# add block volumes
	volumes = blockstorage.list_volumes(compId).data
	for vol in volumes:
		node = {"group": "volumes", "data":{"id": vol.id, "node_data":  vol}}
		nodes.append(node)
	
	response  = str(nodes) 
	response = response.replace("'", '"')
	response = response.replace('u"', '"')

	if args.mode == "FILE":
		file  = open(os.path.join("static" ,  ("network_" + compName + ".json")), "w")
		file.write(response)
		file.close()

	

	if args.mode == "REST" or args.mode == "FILE":
	
		if (args.callback != None and args.callback != "false"):
			print "****** CALLBACK ******"
			response = args.callback + "({'data':" +  response + "})"
		else:
			response = '{"data" :' +  response + '}'

	return response
	

def prepareResponse(response, args):
	if (args.callback != None and args.callback != "false"):
		print "****** CALLBACK ******"
		response = args.callback + "({'data':" +  response + "})"
	else:
		response = '{"data" :' +  response + '}'
			
	return response	

def log(*args):
	if verbose:
		print args

def is_external_cidr(cidr):
    ipnetwork = IPNetwork(cidr)
    if (
            ipnetwork in IPNetwork("10.0.0.0/8") or
            ipnetwork in IPNetwork("172.16.0.0/12") or
            ipnetwork in IPNetwork("192.168.0.0/16")
    ):
        return False
    return True

def is_in_cidr(cidr, ip):
	ip_list = list(cidr)
	if ip in ip_list:
		return True
	else:
		return False
		

class InstanceExtended(Instance):
	privateIpAddress = []
	publicIpAddress = []
	def __init__(self, *args):
		if type(args[0]) is Instance:
			self.__dict__ = args[0].__dict__.copy()
			self.privateIpAddress = []
			self.publicIpAddress = []
			self.attachedVnics  = []
			self.attachedVolumes = []
		else:
			super(InstanceExtended, self).__init__(*args[:2])
	def __str__(self):
		instance = Instance.__str__(self)[1:]
		privIp = str(self.privateIpAddress).replace("'",'"')
		pubIp = str(self.publicIpAddress).replace("'",'"')
		vnics = str(self.attachedVnics).replace("'",'"')
		volumes = str(self.attachedVolumes).replace("'",'"')
		response =  '{' +  '"privateIpAddress":' +  privIp + ',"publicIpAddress":' +  pubIp + ', "vnics":' +  vnics +   ', "volumes":' +  volumes +',' +  instance 
		response = response.replace("'", '"')
		response = response.replace('u"', '"')
		response = response.replace('null,', '"null",')
		response = response.replace('true,', '"true",')
		response = response.replace('false,', '"false",')

		return response
#`		return '{ "privateIpAddress":' +  privIp + ', "publicIpAddress":' +  pubIp + ', "vnics":' +  vnics +  '}'


def createNode(compartment_id, vcn_id, nodedata, nodetype, nodeid, nodename, parentid):
	log("creating node type= " , nodetype , "  Name: ", nodename)
	ocids[nodeid] = {"name": nodename}
	nodeNamesById[nodeid] = nodename
	node = {}
	node_data = {}
	data = {}
	data["vcn_id"] = vcn_id
	data["compartment_id"] = compartment_id
	data["node_data"] = nodedata
	data["id"] = nodeid
	data["type"] = nodetype
	data["name"] = nodename
	if (parentid != "" and parentid != None):
		data ["parent"] = parentid
		try:
			parentName = parentid.split('.')[1] + ":" + nodeNamesById[parentid]
			data ["parentName"] = parentName
		except:
			pass
	if (nodetype == 'oci_vm' or nodetype == 'oci_bm'):
		data["node_data"] = simplejson.loads(str(nodedata))
	node["data"] = data

	node["group"]="nodes"
	return node

def createEdge(compartment_id, vcn_id, label, nodedata, nodetype, nodeid, nodename,  sourceid, targetid):
	log("creating edge source: ", sourceid , " target: ", targetid)
	
	node = createNode(compartment_id, vcn_id, nodedata, nodetype, nodeid, nodename, sourceid)
	data = node["data"]
	data ["source"] = sourceid
	data ["target"] = targetid
	data ["parent"] = ""
	data["name"] = nodename
	data["label"] = label
	data["compartment_id"] = compartment_id
	data["vcn_id"] = vcn_id
	node["data"] = data
	node["group"]="edges"
	

	return node	


# link subnets based on routing table
def subnetRouting(subnet, attached_Vnics, instances):
	#print "instances: ", instances
	routeTable = network.get_route_table(subnet.route_table_id).data
	ocids[routeTable.id] = routeTable
	#print( "**** ROUTING TABLE ****\n", "subnet:", subnet.display_name, "route_table: ",routeTable)
	for routeRule in routeTable.route_rules:
		try:
			#print "Route Rule:", routeRule
			targetName = ""
			targetId = None
			if routeRule.network_entity_id.startswith("ocid1.internetgateway"):
				targetName = network.get_internet_gateway(routeRule.network_entity_id).data.display_name
				targetId = routeRule.network_entity_id
			elif routeRule.network_entity_id.startswith("ocid1.privateip"):
				try:
					privateIp = network.get_private_ip(routeRule.network_entity_id).data
					targetName = privateIp.ip_address
					#print "route to private ip:", targetName
					vnicList = filter(lambda x: x.vnic_id == privateIp.vnic_id, attached_Vnics)
					if len(vnicList) > 0 :
						instList = filter(lambda x: x.id == vnicList[0].instance_id, instances)
						targetId = instList[0].id
					#print "TargetId:", targetId
				except Exception as exip:
					print "targfet IP Address does not exist for route"
			elif routeRule.network_entity_id.startswith("ocid1.localpeeringgateway"):
				targetName = routeRule.cidr_block
				targetId = routeRule.network_entity_id
					
			# should add DRG and local peering
		except Exception as ex:
			print "exception: " , ex
			continue
		
		if not targetId is None:
			edgeid = "edge-" + subnet.id + "/" + routeRule.network_entity_id + "/" + routeRule.cidr_block
			edgename = "RouteTabe:" + routeTable.display_name + " : " + subnet.display_name + "-->" + targetName
			anedge = createEdge(subnet.compartment_id, subnet.vcn_id, routeRule.cidr_block, routeRule,"edge-rl",edgeid,edgename , subnet.id, targetId)
			edges.append(anedge)

		
# add database instances to subnet
def addDbstoSubnet(dbs, subnet):
#	print( "**** SUBNET ****",subnet)
# add db instance to subnet
	for db in dbs:
		if  db.lifecycle_state == 'AVAILABLE':
			dblist = filter(lambda x: x.subnet_id == subnet.id, dbs)
			if len(dblist) > 0:
				nodes.append(createNode(subnet.compartment_id, subnet.vcn_id, db, "oci_dbcs", db.id,db.display_name,subnet.id))

def createLocalPeering(gateways):
	#log("vcns:", vcns)
	for lpgw in gateways:
		#log( "LOCAL PEERING:",lpgw)
# create Local peering node
		lpgwNode = createNode(lpgw.compartment_id, lpgw.vcn_id,lpgw,"oci_lpgw", lpgw.id,lpgw.display_name, lpgw.vcn_id)
		
		sourceVcns = (filter(lambda x: x.id == lpgw.vcn_id, vcns))
		if len(sourceVcns) > 0:
			sourceVcn = sourceVcns[0]
			#log( "sourcevcn:" ,sourceVcn)
			lpgwId = lpgw.id
			nodes.append(lpgwNode)
			try:
				peeredVcns = (filter(lambda x: x.cidr_block == lpgw.peer_advertised_cidr, vcns))
				if peeredVcns != None and len(peeredVcns) > 0:
					peeredVcn = peeredVcns[0]
				
					#log( "Peered Vcn:", peeredVcn)
					targetGateways = (filter(lambda x: x.peer_advertised_cidr == sourceVcn.cidr_block , gateways))
					targetGateway = None
					for tgw in  targetGateways:
						tvcn = (filter(lambda x: x.id == tgw.vcn_id , vcns))[0]
						if tvcn.cidr_block == lpgw.peer_advertised_cidr:
							targetGateway = tgw
							break;
					#log( lpgw.display_name,  " PEERED with :" , targetGateway.display_name)
					edgeid = "peeredvcn." + peeredVcn.id + ":" "sourcelpgw." + lpgw.id + ":" + targetGateway.id
					nodeName = "Peering:" + lpgw.display_name  + " ==>" + targetGateway.display_name
					anedge = createEdge(lpgw.compartment_id, lpgw.vcn_id,"Peering", lpgw, "edge-lpgw", edgeid, nodeName , lpgw.id , targetGateway.id)
					edges.append(anedge)
				
				# print "source gateway:" , lpgw.display_name, " targetgateway", targetGateway.display_name
			except Exception as ex:
				print "Exception:", ex
				traceback.print_exc()
				continue

def createCompartment(regionId, comp):
	#log( "generating compartment: " , comp.name)
	# create compartment node
	compId = comp.id
	nodes.append(createNode(comp.id,"", comp,"oci_compartment",compId,comp.name,regionId))	
	global instances_by_ip
	instances_by_ip = {}	

	#get load  balancers
	lbs = loadbalancer.list_load_balancers(compId).data

	# get db systems
	dbs = database.list_db_systems(compId).data
	
	# get availability domains
	ads = identity.list_availability_domains(rootCompartmentId).data
	
	# get compute instances 
	global extendedInstances
	extendedInstances = {}
	instances = compute.list_instances(compId).data
	for instance in instances:
		ainstance = compute.get_instance(instance.id).data
		extInstance = InstanceExtended(ainstance)
		extendedInstances[extInstance.id] = extInstance

	# get blockvolume attachements
	attached_volumes = compute.list_volume_attachments(compId).data
	
	# get attached VNIcs 
	attached_Vnics = compute.list_vnic_attachments(compId).data
	#log( "VNICS:", attached_Vnics)
	igwId=""

	# get VCNs
	compVcns = network.list_vcns(compId).data
	for vcn in compVcns:
		vcns.append(vcn)
		
	# create all VCNs or only the one specifed by the vcn request parameter
	for vcn in compVcns:
		if (vcnArg == None or vcn.display_name == vcnArg):
			createVcn(vcn, ads, attached_Vnics, attached_volumes, instances)
		
	## add load balancers
	#print "instances_by_ip.keys()\n", instances_by_ip.keys()
	for lb in lbs:
		#log( "*** LOAD BALANCER ****\n",lb.display_name)
#		print( "*** END LOAD BALANCER ****\n")
				

	# compute the backends instnaces  ip addreses
		lb_backend_ips = {}
		lb_backend_bs = {}
		
		for attr, value in lb.backend_sets.iteritems():
			if hasattr(value, "backends"):
				for be in value.backends:
					lb_backend_ips[be.ip_address] = be
					lb_backend_bs [be.ip_address] = attr # this is the backend set name
			
			createLoadBalancerEdges = True
			for sid in lb.subnet_ids:
				lbNodeId =  lb.id + "/" +  sid
				if sid in subnetsById.keys():
					subnet = subnetsById[sid]
					nodes.append(createNode(subnet.compartment_id, subnet.vcn_id,lb,"oci_lb", lbNodeId, lb.display_name, sid))	
					# add edges for the backend  ip addreses, only for the first subnet
					if createLoadBalancerEdges:
						for ip in lb_backend_ips.keys():
							#log( "LB Backend IP:" , ip)
							#log( "instances_by_ip.keys:\n",instances_by_ip.keys())
							if ip in instances_by_ip.keys():
								#log( "IP found in backend ips")
								inst = instances_by_ip[ip]
		#						print "LB Backend IP:" , ip,  " Instance found : ", inst.display_name
								edgeid = "edge-" + lbNodeId + "/" + inst.id
								anedge = createEdge(subnet.compartment_id, subnet.vcn_id, lb_backend_ips[ip].name,lb_backend_ips[ip],"edge-lb",edgeid,"LB:" + lb.display_name  + " :  BackendSet:" + lb_backend_bs[ip] , lbNodeId, inst.id)
								edges.append(anedge)
				createLoadBalancerEdges = False
				
				

	# create CPE nodes
	cpes = network.list_cpes(compId).data
	for cpe in cpes:
		#log( "CPE:", cpe)
		nodes.append(createNode(cpe.compartment_id, cpe.compartment_id,cpe,"oci_cpe", cpe.id, cpe.display_name, None))	

					
	# create DRG nodes
	drgs = network.list_drgs(compId).data
	drgAttachments = network.list_drg_attachments(compId).data
	for drg in drgAttachments:
		#log( "DRG:", drg)
		drgi = 	(filter(lambda x: x.id == drg.drg_id, drgs))[0]

		nodes.append(createNode(drg.compartment_id, drg.compartment_id,drg,"oci_drg", drg.id, drgi.display_name, drg.vcn_id))
		
		# IPSec conections
		ipsecs = network.list_ip_sec_connections(compId).data
		#log( "ipsecs:", ipsecs)
		for ipsec in ipsecs:
			#log( "IPSEC:", ipsec)
			cpe  = 	(filter(lambda x: x.id == ipsec.cpe_id, cpes))[0]
			#log( "CPE FOUND:",cpe)
			edgeid = "edge-" + drg.id + "/" + cpe.id
			anedge = createEdge(drg.compartment_id, drg.compartment_id, lb_backend_ips[ip].name,ipsec,"edge-drg",edgeid,"DRG:" + drg.display_name  + " ==>" + cpe.display_name , drg.id, cpe.id)
			edges.append(anedge)

		
		
def createVcn(vcn, ads, attached_Vnics, attached_volumes, instances):
	
	log( "generating VCN: " , vcn.display_name)
	compId = vcn.compartment_id
	regionId = vcn.id.split(".")[3]
	log( "regionid:", regionId)
	
	# create VCN node
	nodes.append(createNode(compId, vcn.id,vcn,"oci_vcn",vcn.id, vcn.display_name,compId))
	# Get Subnets in VCN
	subnets = network.list_subnets(compId, vcn.id).data
	
	# Create the Availability Domains for this vcn
	adids = {}
	for subnet in subnets:
		subnetsById[subnet.id] = subnet
		# print "***** SUBNET *****\n",subnet, "\n*********************************"
		ADId = vcn.id + "/" + subnet.availability_domain
		anAd = (filter(lambda x: x.name == subnet.availability_domain, ads))[0]
		# create Availability Domain nodes present in this VCN
		if ADId not in  adids.keys():
			adids[ADId] = anAd
			nodes.append(createNode(vcn.compartment_id, vcn.id,anAd,"oci_ad",ADId,anAd.name,vcn.id))
		
	# Internet gateways
	igws = network.list_internet_gateways(compId, vcn.id).data

	# get localpeering Gateways in VCNs
	lpgws = network.list_local_peering_gateways(compId, vcn.id).data
	# Route tables
	route_tables = network.list_route_tables(compId, vcn.id).data
	
	for lpgw in lpgws:
		localPeeringGateways.append(lpgw)

		
	# create Internet Gateway nodes
	for igw in igws:
		igwNode = createNode(vcn.compartment_id, vcn.id,igw,"oci_igw", igw.id,igw.display_name,vcn.id)
		igwId = igw.id
		nodes.append(igwNode)
	
	# create subnets
	for subnet in subnets:
		# add Subnet
		ADId = vcn.id + "/" + subnet.availability_domain
		log("Subnet:", subnet)
		nodes.append(createNode(vcn.compartment_id, vcn.id,subnet,"subnet",subnet.id,subnet.display_name,ADId))
		
		# get Private Ips in subnet

		privateips = network.list_private_ips(subnet_id=subnet.id).data
		for privateIp in privateips:
			#print( "**** PRIVATE IP **** \n", privateIp)
			privateIpsById[privateIp.id] = privateIp
			vnicList = filter(lambda x: x.vnic_id == privateIp.vnic_id, attached_Vnics)
			if len(vnicList) > 0 :
				instList = filter(lambda x: x.id == vnicList[0].instance_id, instances)
				instance = extendedInstances[vnicList[0].instance_id]
				instance.privateIpAddress.append(privateIp.ip_address)
				vnic = network.get_vnic(vnicList[0].vnic_id).data
				instance.attachedVnics.append(vnic)
				extendedInstances[vnicList[0].instance_id] = instance
				instances_by_ip[privateIp.ip_address] = instance
			# find volumes attached to instance
			volumeList = filter(lambda x: x.instance_id == instance.id, attached_volumes)
			for vol in volumeList:
				instance.attachedVolumes.append(vol)
				

		for aninstance in extendedInstances.values():
			for anip in aninstance.privateIpAddress:
				if IPAddress(anip) in IPNetwork(subnet.cidr_block):
					nodetype="oci_vm"
					if aninstance.shape.startswith("BM."):
						nodetype = "oci_bm"
					nodes.append(createNode(vcn.compartment_id, vcn.id,aninstance,nodetype,aninstance.id,aninstance.display_name,subnet.id))
					break;
		# add db instance to subnet
		addDbstoSubnet(dbs, subnet)
		
		# connect subnet based on route table
		subnetRouting(subnet, attached_Vnics, instances)
			
	
	#log( "**** FINDING EDGES BASED ON SECURItY LISTS ****")
	for subnet in subnets:
# find edges between subnets and instances
		subnetIsPublic = False
		if (subnet.prohibit_public_ip_on_vnic == False):
			subnetIsPublic = True
		#print( "subnet:", subnet.display_name, " ", subnet.cidr_block)
		for slid in subnet.security_list_ids:
			sl = network.get_security_list(slid).data
			ocids[slid] = sl
			#log( "*** SECURITY LIST ****\n", sl)
			for rule in sl.ingress_security_rules:
				#log( "rule.source:", rule.source)
				port = ""
				protocol = rule.protocol
				if (protocol == "6"): # TCP
					protocol = "TCP"
					if not rule.tcp_options is None:
						if rule.tcp_options.destination_port_range.min == rule.tcp_options.destination_port_range.max:
							port = rule.tcp_options.destination_port_range.min
						else:
							port = str(rule.tcp_options.destination_port_range.min) + ":" + str(rule.tcp_options.destination_port_range.max)
				if (rule.protocol == "1"): # ICMP
					protocol = "ICMP"
					if not rule.icmp_options is None:
						port = str(rule.icmp_options.code) + ":" + str(rule.icmp_options.type)
				label = protocol + ":"  + str(port)				
				
				if is_external_cidr(rule.source) and subnetIsPublic :
					#log( "rule.source:", rule.source, " is external")
					if rule.source not in external_cidrs.keys():
						external_cidrs[rule.source] = 1
						nodes.append(createNode(vcn.compartment_id, vcn.id,1,"ip", rule.source,rule.source,""))
					edgeid = "edge-" + subnet.id + "/" + rule.source
					anedge = createEdge(subnet.compartment_id, subnet.vcn_id,label,rule,"edge-sl",edgeid,"rule", rule.source, subnet.id)
					edges.append(anedge)

				else:
					if rule.source.endswith("/32"):
						#log( " ***** Rule is for private ip")
						pip = (rule.source.replace("/32",""))
						#log( "pip=:", pip)
						if pip.encode("utf-8") in instances_by_ip.keys():
							#print( "ip found in instances")
							sourceInstance = instances_by_ip[pip]
							edgeid = "edge-" + sourceInstance.id + "/" + subnet.id
							anedge = createEdge(subnet.compartment_id, subnet.vcn_id, label, rule,"edge-sl",edgeid,"rule", sourceInstance.id, subnet.id)
							edges.append(anedge)
							#print( "*** CREtaE EDGE ****\n", anedge	)
					else:
						for targSubnet in subnets:
							#log( "checking source subnet:", targSubnet.display_name, " ",targSubnet.cidr_block, " rule_cidr:",rule.source)
							tn = IPNetwork(rule.source)
							sn =  IPNetwork(targSubnet.cidr_block) 
							#log( "tn:", tn,  "\n sn:" , sn)
							if (tn in sn):
								#log( "tn in sn)")
								if tn in sn and sl.id  not in targSubnet.security_list_ids:
									edgeid = "edge-" + targSubnet.id + "/" + subnet.id

								anedge = createEdge(subnet.compartment_id, subnet.vcn_id, label,rule,"edge-sl",edgeid,"rule", targSubnet.id, subnet.id)
								edges.append(anedge)
								
								break;
	#log( "instances_by_ip\n",instances_by_ip	)



	
## global variables



if __name__ == "__main__":
    main()
		

	